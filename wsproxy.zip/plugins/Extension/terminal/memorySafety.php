<?php

namespace plugins;

class memorySafety
{

}