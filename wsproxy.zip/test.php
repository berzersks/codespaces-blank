<?php

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.rapidopagamentos.com.br/v1/transactions",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode([
        'amount' => 10000,
        'paymentMethod' => 'pix',
        'customer' => [
            'name' => 'RapidoPay Intermediação de Pagamento',
            'email' => 'email@rapidopayments.com.br',
            'document' => [
                'number' => '81601884044',
                'type' => 'cpf'
            ],
            'phone' => '19997999922'
        ],
        'items' => [
            [
                'title' => 'Caixa box',
                'unitPrice' => 1000,
                'quantity' => 1,
                'tangible' => false
            ]
        ]
    ]),
    CURLOPT_HTTPHEADER => [
        "accept: application/json",
        "authorization: Basic YXRfdWhzYTVCY1BhcFRNU0B3djVaZnFQbFp2R3MtbW1kREdKa3hieWJ3RWxCWUpAaFRsOng=",
        "content-type: application/json"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    echo $response;
}